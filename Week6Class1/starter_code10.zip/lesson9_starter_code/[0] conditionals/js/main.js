
// -------------------------------------------------------------------------------
// Part 1 - Compare two numbers! (use the cheat sheet for reference)
// -------------------------------------------------------------------------------

// 1. Declare a variable with the name "number1". Give it a value of 4.

// 2. Declare a variable with the name "number2". Give it a value of 10.


// 3. Write out an if / else if / else statement for the following conditions:

// if number1 is equal to number2
	// $('h1').html(number1 + " is equal to " + number2);

// else if number1 is less than number2
	// $('h1').html(number1 + " is less than " + number2);

// else
	// $('h1').html(number1 + " is greater than " + number2);



// -------------------------------------------------------------------------------
// Bonus - Find the highest number!
// -------------------------------------------------------------------------------

// 1. Declare a variable with the name "number3". Give it a value of 8.

// 2. Declare a variable with the name "number4". Give it a value of 2.

// 3. Declare a variable with the name "number5". Give it a value of 3.


// 3. Write out an if / else if / else statement for the following conditions (Hint: you'll need to use some logical operators in your conditions)

// if number3 is greater than number4 AND number3 is greater than number5
	// $('h2').html(number3 + " is the highest number");

// else if number4 is greater than number3 AND number4 is greater than number5
	// $('h2').html(number4 + " is the highest number");

// else
	// $('h2').html(number5 + " is the highest number");


	
